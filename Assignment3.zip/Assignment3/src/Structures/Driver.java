package Structures;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.HashMap;

public class Driver {
	public static void main(String[] args) throws IOException {

		File outfile = new File("output.txt");
		File infile = new File("input.txt");
		File readfile = new File("words.txt");
		FileWriter fw = new FileWriter(outfile);
		PrintWriter pw = new PrintWriter(fw);
		Scanner fileRead = new Scanner(readfile);
		Scanner fileIn = new Scanner (infile);
		int capacity = (int) ((int) readfile.length() * 1.5);
		pw.println("=================TABLE=====================");
		while(capacity > 27000) {
				pw.println("\t\t\tTableSize = " + capacity);
				pw.println("===========================================");
				//Start time for personal table
				long start = System.nanoTime();
				long end = System.nanoTime();
				double runtime = (end - start) * 1.0 / 1000000000;
				HashTable table = new HashTable(capacity);
				//Add everything to Personal HashTable
				while(fileRead.hasNext()) {
					String temp = fileRead.nextLine();
					Anagram gram = new Anagram(temp);				
					table.add(gram);					
				}
				//Prints number of collisions
				pw.println("Personal Collision count = " + table.getCollision());
			
				// End runtime for personal table
				end = System.nanoTime();
				runtime = (end - start) * 1.0 / 1000000000;
				// Personal Table
				pw.println("Personal runtime = " + runtime);
				
				
				//Java hashCode
				fileRead = new Scanner(readfile);
				HashTable compT = new HashTable();
				//Adds everything to a new table using Java hashCode
				while(fileRead.hasNext()) {
					String temp = fileRead.nextLine();
					Anagram gram = new Anagram(temp);				
					compT.JavasAdd(gram);	
				}
				//Prints number of collisions
				pw.println("Java Hashcode Collision count = " + compT.getCollision());
				
				// Java's HashMap start time
				start = System.nanoTime();
				HashMap<String, String> javaMap = new HashMap<String, String>(capacity);
				fileRead = new Scanner(readfile);
				while(fileRead.hasNext()) {
					String temp = fileRead.nextLine();
					Anagram gram = new Anagram(temp);	
					javaMap.put(gram.getKey(),gram.getValues());
				}
				//End time for Java HashMap
				end = System.nanoTime();
				runtime = (end - start) * 1.0 / 1000000000;
				// Java's Map runtime
				pw.println("Java HashMap runtime = " + runtime);
				
				capacity /= 2;
				fileRead = new Scanner(readfile);

				pw.println("===========================================");

		}
		
		
		HashTable table = new HashTable();
		//Add everything to Personal HashTable
		while(fileRead.hasNext()) {
			String temp = fileRead.nextLine();
			Anagram gram = new Anagram(temp);				
			table.add(gram);					
		}
		//Input file portion
		while(fileIn.hasNext()) {
			String temp = fileIn.nextLine();
			Anagram gram = new Anagram(temp);	
			pw.print(temp + " ");
			//search only if index is valid
			if(table.search(gram) >= 0) {
				//access searched Anagram
				Anagram current = table.table[(int) table.search(gram)];
				//print similar Anagrams.
				pw.println(current.getWordCount() + " " + current.getValues());	
			}
			else {
				pw.println("0");	
			}
		}
		pw.flush();
		pw.close();
	}
}


 