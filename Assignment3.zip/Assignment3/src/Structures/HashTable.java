/*
 * TCSS 342 - Project 3
 */
package Structures;

public class HashTable extends Anagram {
	
	/** 
	 * Stores all anagrams.
	 */
	Anagram[] table;
	
	/**
	 * Counts the amount of times collision has occurred.
	 */
	private int collision;
	
	/**
	 * Table size
	 */
	private int capacity = 309993;
	
	/**
	 * Instantiates a HashTable	
	 */
	public HashTable() {
		collision = 0;
		capacity = 309993;
		table = new Anagram[capacity];
	}
	
	public HashTable(int capacity) {
		collision = 0;
		this.capacity = capacity;
		table = new Anagram[capacity];
	}
	
	/**
	 * Searches whether a word exists or not in the table
	 * @param Key sorted word to be searched 
	 * @return index position of searched word, -1 if not found.
	 */
	public long search(Anagram Key) {
		long hash = hashCode(Key);
		if (table[(int) hash] != null && table[(int) hash].getKey().equals(Key.getKey())) {				
			return hash;
		}
		else if (table[(int) hash] != null && hash >= 0 && !table[(int) hash].getKey().equals(Key.getKey())) {				
			hash = quadraticSearch(hash, Key, 0);		
		}
		else {
			hash = -1;
		}
		return hash;
	}
	
	/**
	 * Handles collisions when searching.
	 * @param index hashCode of key value.
	 * @param gram word to be searched
	 * @param i start at 0, used for recursion.
	 * @return index position of gram, -1 if not found.
	 */
	public long quadraticSearch(long index, Anagram gram, int i) {
		long hashCode = index; 
		hashCode += (int) Math.pow(i, 2);
		i++;
		hashCode = hashCode % capacity;
		if(table[(int) hashCode] != null && table[(int)hashCode].getKey().equals(gram.getKey())) {
			return hashCode;
		}
		else if(table[(int)hashCode] == null) {
			hashCode = -1;
			return hashCode;
		}
		else {
			hashCode = quadraticSearch(hashCode, gram, i);
		}
		return hashCode;
	}
	
	/**
	 * Quadratic probing when hashCode() reaches a collision.
	 * @param index hashCode of key value
	 * @param gram word to be inserted.
	 * @param i used for recursion, starts a 0.
	 * @return index value of where gram belongs.
	 */
	public long quadratic(long index, Anagram word, int i) {
		long hashCode = index;
		hashCode += (int) Math.pow(i, 2);
		i++;
		hashCode = hashCode % capacity;
		if(table[(int) hashCode] != null && table[(int) hashCode].getKey().equals(word.getKey())) {
			return hashCode;
		}
		else if(table[(int) hashCode] == null) {
			return hashCode;
		}
		else {
			hashCode = quadratic(hashCode, word, i);	
		}
		return hashCode;
	}	
	
	/**
	 * Adds new Anagrams to the table
	 * @param word new word value to be added.
	 */
	public void add(Anagram word) {
		long hash = hashCode(word);
		if(table[(int) hash] == null) {
			table[(int) hash] = word;
		}
		else if(table[(int) hash] != null && table[(int) hash].getKey().equals(word.getKey())) {
			table[(int) hash].addValue(word.getValues());		
		}
		else {
			collision++;
			hash = quadratic(hash, word, 0);	
			if(table[(int)hash] == null) {
				table[(int) hash] = word;
			}
			else if (table[(int)hash].getKey().equals(word.getKey())) {
				table[(int) hash].addValue(word.getValues());
			}
		}
	}
	
	/**
	 * Uses Java String hashCode to add
	 * @param word the word value to be added to table
	 */
	public void JavasAdd(Anagram word) {
		long hash = word.getKey().hashCode();
		hash = Math.abs(hash) % capacity;
		if(table[(int) hash] == null) {
			table[(int) hash] = word;
		}
		else if(table[(int) hash] != null && table[(int) hash].getKey().equals(word.getKey())) {
			table[(int) hash].addValue(word.getValues());
		}
		else {
			collision++;
			hash = quadratic(hash, word, 0);	
			if(table[(int)hash] == null) {
				table[(int) hash] = word;
			
			}
			else if (table[(int)hash].getKey().equals(word.getKey())) {
				table[(int) hash].addValue(word.getValues());
			}
		}
	}

	/**
	 * Converts Key value to a long which is used 	as an index position.
	 * @param word Anagram that is used to find key value.
	 * @return index position of where gram belongs.
	 */
	public long hashCode(Anagram word) {
		long hash = 7;
		String temp = word.getKey();
		for(int i = 0; i < temp.length(); i++) {
			hash = 17 * hash + temp.charAt(i);
		}
		return Math.abs(hash) % capacity;
	}

	public int getCollision() {
		return collision;
	}
}
