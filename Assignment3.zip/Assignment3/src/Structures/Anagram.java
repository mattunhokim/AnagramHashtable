/*
 * TCSS 342 - Project 3
 */

package Structures;

import java.util.Arrays;

/**
 * Implementation of Anagram.
 * @author Matthew Kim
 * @version Fall 2022
 *
 */
public class Anagram  {
	
	/**
	 * Input word.
	 */
	private String word;
	
	/**
	 * Sorted value input. 
	 */
	private String key;
	
	/**
	 * Number of words with equal keys.
	 */
	public int wordcount;
	
	/**
	 * Instantiates a new Anagram Object
	 */
	public Anagram() {
		word = null;
		key = null;
		wordcount = 1;
	}
	
	/**
	 * Instantiates a new Anagram Object with String value.
	 */
	public Anagram(String word) {
		this.word = word;
		wordcount = 1;
		this.key = generateKey();
	}
		
	/**
	 * Adds word similar Anagrams into a collection represented as a string.
	 * @param value inserted word
	 */
	public void addValue(String value) {
		word += " " + value;
		wordcount++;
	}
	
	/**
	 * Sorts the value of word in ASCII order
	 * @return a value that can be used to compare other Anagrams.
	 */
	private String generateKey() {
	        char[] letters = word.toString().toCharArray();
	        Arrays.sort(letters);
	        String temp = new String(letters);
	        return temp;
	}
	
	public int getWordCount() {
		return wordcount;
	}
		
	public String getValues() {
		return word;
	}
	
	public String getKey() {
		return key;
	}
	
}